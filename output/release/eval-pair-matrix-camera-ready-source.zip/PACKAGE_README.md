# Camera-ready LaTeX sources

From this extracted directory run `bash paper/build_camera_ready.sh`. Requires Python 3 and pdfLaTeX. The build verifies official ACL style hashes and writes `output/pdf/eval-pair-matrix-camera-ready.pdf`. Only referenced figures/tables and the final manuscript are included.
