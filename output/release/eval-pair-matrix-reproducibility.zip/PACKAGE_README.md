# Reproducibility package

See `paper/REPRODUCIBILITY.md` for saved-data analysis commands and expected results. These commands make no model calls. The source pool, labeled generations, verdicts, human audit inputs, prompts/schemas, and usage-only ledger are included. Each packaged file is hashed in `SHA256SUMS.json`. Upstream data provenance and terms continue to apply.
